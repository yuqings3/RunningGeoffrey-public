package com.example.runninggeoffrey.Listener;

public interface VolumeListener {
    void volumeChangeListener(double volumeValue);
}
